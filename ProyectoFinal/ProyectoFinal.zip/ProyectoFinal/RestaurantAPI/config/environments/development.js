module.exports = {
  logError: true,
  urlBase:'',
  neo4j:{
    url:"bolt://localhost",
    username:"neo4j",
    password:"admin"
  },
  secret: 'miSecretoMaximo'
};
