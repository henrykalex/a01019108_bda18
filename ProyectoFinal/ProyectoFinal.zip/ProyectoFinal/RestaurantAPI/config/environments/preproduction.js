module.exports = {
  logError: true,
  urlBase:'/restaurantapi',
  neo4j:{
    url:"bolt://neo4j",
    username:"neo4j",
    password:"123456"
  },
  secret: 'miSecretoMaximo'
};
