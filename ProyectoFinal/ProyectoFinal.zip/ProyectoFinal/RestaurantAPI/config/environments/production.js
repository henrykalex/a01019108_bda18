module.exports = {
  logError: true,
  urlBase:'restaurantapi',
  neo4j:{
    url:"bolt://localhost"
  },
  secret: 'miSecretoMaximo'
};
